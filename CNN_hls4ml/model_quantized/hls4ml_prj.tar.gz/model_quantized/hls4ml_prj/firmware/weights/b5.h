//Numpy array shape [12]
//Min 0.000000000000
//Max 0.312500000000
//Number of zeros 4

#ifndef B5_H_
#define B5_H_

#ifndef __SYNTHESIS__
bias5_t b5[12];
#else
bias5_t b5[12] = {0.187500, 0.062500, 0.000000, 0.031250, 0.125000, 0.187500, 0.312500, 0.000000, 0.000000, 0.125000, 0.062500, 0.000000};
#endif

#endif
