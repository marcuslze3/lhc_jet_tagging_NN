//Numpy array shape [8]
//Min -0.031250000000
//Max 0.218750000000
//Number of zeros 1

#ifndef B5_H_
#define B5_H_

#ifndef __SYNTHESIS__
bias5_t b5[8];
#else
bias5_t b5[8] = {0.062500, 0.062500, -0.031250, 0.093750, 0.156250, 0.156250, 0.000000, 0.218750};
#endif

#endif
