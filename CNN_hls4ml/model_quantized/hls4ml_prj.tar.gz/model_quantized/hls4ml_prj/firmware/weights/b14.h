//Numpy array shape [5]
//Min -0.281250000000
//Max 0.375000000000
//Number of zeros 0

#ifndef B14_H_
#define B14_H_

#ifndef __SYNTHESIS__
bias14_t b14[5];
#else
bias14_t b14[5] = {0.062500, -0.187500, 0.031250, -0.281250, 0.375000};
#endif

#endif
