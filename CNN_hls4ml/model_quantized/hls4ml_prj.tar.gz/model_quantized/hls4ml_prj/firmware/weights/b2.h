//Numpy array shape [8]
//Min -0.156250000000
//Max 0.250000000000
//Number of zeros 0

#ifndef B2_H_
#define B2_H_

#ifndef __SYNTHESIS__
bias2_t b2[8];
#else
bias2_t b2[8] = {-0.062500, -0.062500, 0.093750, 0.187500, 0.250000, -0.156250, 0.187500, 0.218750};
#endif

#endif
