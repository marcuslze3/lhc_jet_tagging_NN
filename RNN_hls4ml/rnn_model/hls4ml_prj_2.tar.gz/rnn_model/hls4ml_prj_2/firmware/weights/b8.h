//Numpy array shape [5]
//Min -0.246570080519
//Max 0.158947795630
//Number of zeros 0

#ifndef B8_H_
#define B8_H_

#ifndef __SYNTHESIS__
output_bias_t b8[5];
#else
output_bias_t b8[5] = {-0.1266593486, 0.1589477956, 0.1171885282, -0.2465700805, 0.0783231854};
#endif

#endif
