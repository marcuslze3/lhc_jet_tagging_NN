//Numpy array shape [5]
//Min -0.238918170333
//Max 0.152716755867
//Number of zeros 0

#ifndef B8_H_
#define B8_H_

#ifndef __SYNTHESIS__
output_bias_t b8[5];
#else
output_bias_t b8[5] = {-0.2389181703, 0.0409360677, 0.1527167559, -0.0772420317, 0.1056860760};
#endif

#endif
