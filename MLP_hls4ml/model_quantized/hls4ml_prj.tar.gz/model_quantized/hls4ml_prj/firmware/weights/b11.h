//Numpy array shape [5]
//Min -0.093750000000
//Max 0.125000000000
//Number of zeros 0

#ifndef B11_H_
#define B11_H_

#ifndef __SYNTHESIS__
bias11_t b11[5];
#else
bias11_t b11[5] = {-0.093750, 0.031250, 0.125000, 0.031250, -0.031250};
#endif

#endif
